package co.edu.uniquindio.finalprojectfx.finalprojectapp;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.viewcontroller.MarketPlaceAppController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MarketPlaceApplication extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader marketplaceLoader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/finalprojectfx/finalprojectapp/MarketPlaceApp.fxml"));
        Scene scene = new Scene(marketplaceLoader.load());
        MarketPlaceAppController marketPlaceAppController = marketplaceLoader.getController();
        primaryStage.setScene(scene);
        primaryStage.setTitle("MarketPlace Application");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}