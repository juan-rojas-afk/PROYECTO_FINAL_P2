package co.edu.uniquindio.finalprojectfx.finalprojectapp.service;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.mapping.dto.ProductoDto;
import co.edu.uniquindio.finalprojectfx.finalprojectapp.mapping.dto.VendedorDto;

import java.util.List;

public interface IModelFactoryService {
    List<VendedorDto> obtenerVendedores();
    boolean agregarVendedor(VendedorDto vendedorDto);
    boolean eliminarVendedor(String cedula);
    boolean actualizarVendedor(String cedulaActual, VendedorDto vendedorDto);

    List<ProductoDto> obtenerProductos();
    boolean agregarProducto(ProductoDto productoDto);
    boolean eliminarProducto(String nombre);
    boolean actualizarProducto(String nombreActual, ProductoDto productoDto);


    boolean publicarProducto(ProductoDto productoPublicado);


    List<ProductoDto> obtenerProductosVendedor(String usuario);



    int obtenerCantidadLikes(String nombre);

    boolean agregarLike(String nombre, String usuario);

    boolean tieneUsuarioLike(String nombre, String usuario);

    boolean agregarComentario(String nombre, String comentario, String usuario);

    List<String> obtenerComentarios(String nombre);

    List<ProductoDto> obtenerProductosPublicados();
}
