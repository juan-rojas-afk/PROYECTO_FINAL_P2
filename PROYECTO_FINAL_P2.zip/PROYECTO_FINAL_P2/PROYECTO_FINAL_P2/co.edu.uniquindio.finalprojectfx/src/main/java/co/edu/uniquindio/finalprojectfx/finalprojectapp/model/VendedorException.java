package co.edu.uniquindio.finalprojectfx.finalprojectapp.model;

public class VendedorException extends Exception {
    public VendedorException(String mensaje ) {
        super(mensaje);
    }
}

