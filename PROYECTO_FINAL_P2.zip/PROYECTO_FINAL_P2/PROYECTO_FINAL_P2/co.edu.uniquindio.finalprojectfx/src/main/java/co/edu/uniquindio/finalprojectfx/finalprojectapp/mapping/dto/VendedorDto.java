package co.edu.uniquindio.finalprojectfx.finalprojectapp.mapping.dto;

public record VendedorDto(
    String nombre,
    String apellidos,
    String cedula,
    String direccion,
    String usuario,
    String contrasena
) {
}
