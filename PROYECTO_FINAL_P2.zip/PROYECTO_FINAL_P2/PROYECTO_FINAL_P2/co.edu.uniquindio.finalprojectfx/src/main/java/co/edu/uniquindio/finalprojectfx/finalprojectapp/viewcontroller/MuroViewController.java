package co.edu.uniquindio.finalprojectfx.finalprojectapp.viewcontroller;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.controller.MuroController;
import co.edu.uniquindio.finalprojectfx.finalprojectapp.mapping.dto.ProductoDto;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import static co.edu.uniquindio.finalprojectfx.finalprojectapp.utils.MarketPlaceConstantes.*;

public class MuroViewController {

    ObservableList<ProductoDto> productosPublicados = FXCollections.observableArrayList();
    MuroController muroController;
    ObservableList<ProductoDto> listaProductos = FXCollections.observableArrayList();
    ProductoDto productoSeleccionado;
    private String usuarioActual;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btnAgregarVendedor;

    @FXML
    private Button btnComentar;

    @FXML
    private Button btnLike;

    @FXML
    private ImageView imagenProducto;

    @FXML
    private Label lbContadorLikes;

    @FXML
    private ListView<String> lvComentarios;

    @FXML
    private TableView<ProductoDto> tableProductosAsociados;

    @FXML
    private TableColumn<ProductoDto, String> tcCategoriaAsociado;

    @FXML
    private TableColumn<ProductoDto, String> tcDescripcionAsociada;

    @FXML
    private TableColumn<ProductoDto, LocalDate> tcFechaAsociada;

    @FXML
    private TableColumn<ProductoDto, String> tcNombreAsociado;

    @FXML
    private TableColumn<ProductoDto, Double> tcPrecioAsociado;


    @FXML
    private TableView<ProductoDto> tableProductosVendedores;

    @FXML
    private TableColumn<ProductoDto, String> tcNombreProducto;

    @FXML
    private TableColumn<ProductoDto, String> tcDescripcionProducto;

    @FXML
    private TableColumn<ProductoDto, String> tcCategoriaProducto;

    @FXML
    private TableColumn<ProductoDto, LocalDate> tcFechaProducto;

    @FXML
    private TableColumn<ProductoDto, Double> tcPrecioCategoria;

    @FXML
    private TextField txtApellidos;

    @FXML
    private TextField txtComentario;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtUsuario;

    @FXML
    void initialize() {
        muroController = new MuroController();
        initView();
        obtenerProductosPublicados();
        obtenerProductos();
    }

    private void initView() {
        initDataBinding();
        initDataBindingProductosPublicados();

        tableProductosAsociados.getItems().clear();
        tableProductosAsociados.setItems(listaProductos);

        tableProductosVendedores.getItems().clear();
        tableProductosVendedores.setItems(productosPublicados);

        listenerSelection();
        listenerSelectionPublicados();
    }

    private void obtenerProductosPublicados() {
        productosPublicados.clear();
        List<ProductoDto> productos = muroController.obtenerProductosPublicados();
        if (productos != null && !productos.isEmpty()) {
            productosPublicados.addAll(productos);
        }
        tableProductosVendedores.getItems().clear();
        tableProductosVendedores.setItems(productosPublicados);
        tableProductosVendedores.refresh();
    }

    public void actualizarProductosPublicados() {
        obtenerProductosPublicados();
    }

    private void initDataBindingProductosPublicados() {
        tcNombreProducto.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().nombre()));
        tcCategoriaProducto.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().categoria()));
        tcPrecioCategoria.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().precio()));
        tcFechaProducto.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().fechaPublicacion()));
        tcDescripcionProducto.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().descripcion()));
    }

    private void obtenerProductos() {
        listaProductos.addAll(muroController.obtenerProducto());
    }

    private void initDataBinding() {
        tcNombreAsociado.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().nombre()));
        tcCategoriaAsociado.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().categoria()));
        tcPrecioAsociado.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().precio()));
        tcFechaAsociada.setCellValueFactory(cellData -> new SimpleObjectProperty<>(cellData.getValue().fechaPublicacion()));
        tcDescripcionAsociada.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().descripcion()));
    }

    private void listenerSelection() {
        tableProductosAsociados.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            productoSeleccionado = newSelection;
            mostrarInformacion(productoSeleccionado);
            actualizarListaComentarios();
            if (productoSeleccionado != null && txtUsuario.getText() != null) {
                boolean tienelike = muroController.tieneUsuarioLike(
                        productoSeleccionado.nombre(),
                        txtUsuario.getText()
                );
                btnLike.setStyle(tienelike ? "-fx-background-color: #0066cc;" : "");
            }
        });
    }

    private void listenerSelectionPublicados() {
        tableProductosVendedores.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            productoSeleccionado = newSelection;
            if (productoSeleccionado != null) {
                mostrarInformacion(productoSeleccionado);
                actualizarListaComentarios();
                actualizarContadorLikes();

                if (txtUsuario.getText() != null && !txtUsuario.getText().isEmpty()) {
                    boolean tienelike = muroController.tieneUsuarioLike(
                            productoSeleccionado.nombre(),
                            txtUsuario.getText()
                    );
                    btnLike.setStyle(tienelike ? "-fx-background-color: #0066cc;" : "");
                }
            }
        });
    }

    private void mostrarInformacion(ProductoDto productoSeleccionado) {
        if(productoSeleccionado != null) {
            cargarImagen(productoSeleccionado.imagen());
        }
    }

    private void cargarImagen(String imagen) {
        try {
            imagenProducto.setVisible(true);
            imagenProducto.setImage(new Image("file:" + productoSeleccionado.imagen()));
            System.out.println(productoSeleccionado.imagen());
        } catch (Exception e) {
            imagenProducto.setImage(null);
            mostrarMensaje(TITULO_ERRROR_IMAGEN, BODY_ERRROR_IMAGEN+ e.getMessage(), HEADER, Alert.AlertType.ERROR);
        }
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert aler = new Alert(alertType);
        aler.setTitle(titulo);
        aler.setHeaderText(header);
        aler.setContentText(contenido);
        aler.showAndWait();
    }

    @FXML
    void btnAgregarVendedor(ActionEvent event) {

    }

    @FXML
    void onComentar(ActionEvent event) {
        comentarPublicacion();
    }

    private void comentarPublicacion() {
        if (productoSeleccionado != null) {
            String comentario = txtComentario.getText();
            if (comentario != null && !comentario.trim().isEmpty()) {
                String usuario = txtUsuario.getText();
                if (usuario == null || usuario.trim().isEmpty()) {
                    mostrarMensaje("Error", "Usuario requerido", "Debe ingresar un usuario para comentar", Alert.AlertType.WARNING);
                    return;
                }
                boolean comentarioAgregado = muroController.agregarComentario(productoSeleccionado.nombre(),
                        comentario, usuario);

                if(comentarioAgregado) {
                    actualizarListaComentarios();
                    txtComentario.clear();
                    mostrarMensaje("Comentario agregado", "Éxito", "Se ha agregado el comentario correctamente", Alert.AlertType.INFORMATION);
                } else {
                    mostrarMensaje("Error", "Error al comentar", "No se pudo agregar el comentario", Alert.AlertType.ERROR);
                }
            } else {
                mostrarMensaje("Error", "Comentario vacío", "Debe escribir un comentario", Alert.AlertType.WARNING);
            }
        } else {
            mostrarMensaje("Error", "Selección requerida", "Debe seleccionar un producto primero", Alert.AlertType.WARNING);
        }
    }

    private void actualizarListaComentarios() {
        if (productoSeleccionado != null) {
            ObservableList<String> comentarios = FXCollections.observableArrayList(
                    muroController.obtenerComentarios(productoSeleccionado.nombre())
            );
            lvComentarios.setItems(comentarios);
        }
    }


    @FXML
    void onDarLike(ActionEvent event) {
        agregarLike();
    }

    private void agregarLike() {
        if (productoSeleccionado != null) {
            String usuario = txtUsuario.getText();
            if (usuario == null || usuario.trim().isEmpty()) {
                mostrarMensaje("Error", "Usuario requerido", "Debe ingresar un usuario para dar like", Alert.AlertType.WARNING);
                return;
            }

            boolean likeAgregado = muroController.agregarLike(productoSeleccionado.nombre(), usuario);
            actualizarContadorLikes();

            if (likeAgregado) {
                btnLike.setStyle("-fx-background-color: #0066cc;");
                mostrarMensaje("Like agregado", "Éxito", "Se ha agregado el like correctamente", Alert.AlertType.INFORMATION);
            } else {
                btnLike.setStyle("");
                mostrarMensaje("Like removido", "Éxito", "Se ha removido el like correctamente", Alert.AlertType.INFORMATION);
            }
        } else {
            mostrarMensaje("Error", "Selección requerida", "Debe seleccionar un producto primero", Alert.AlertType.WARNING);
        }
    }

    private void actualizarContadorLikes() {
        if (productoSeleccionado != null) {
            int cantidadLikes = muroController.obtenerCantidadLikes(productoSeleccionado.nombre());
            lbContadorLikes.setText(String.valueOf(cantidadLikes));
        }
    }
}