package co.edu.uniquindio.finalprojectfx.finalprojectapp.controller;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.factory.ModelFactory;
import co.edu.uniquindio.finalprojectfx.finalprojectapp.mapping.dto.ProductoDto;

import java.util.List;

public class MuroController {

    ModelFactory modelFactory;
    public MuroController() {
        modelFactory = ModelFactory.getInstance();
    }

    public List<ProductoDto> obtenerProducto() {
        return modelFactory.obtenerProductos();
    }


    public boolean agregarLike(String nombre, String usuario) {
        return modelFactory.agregarLike(nombre, usuario);
    }

    public boolean tieneUsuarioLike(String nombre, String usuario) {
        return modelFactory.tieneUsuarioLike(nombre, usuario);
    }

    public boolean agregarComentario(String nombre, String comentario, String usuario) {
        return modelFactory.agregarComentario(nombre, comentario, usuario);
    }

    public List<String> obtenerComentarios(String nombre) {
        return modelFactory.obtenerComentarios(nombre);
    }

    public int obtenerCantidadLikes(String nombre) {
        return modelFactory.obtenerCantidadLikes(nombre);
    }

    public List<ProductoDto> obtenerProductosPublicados() {
        return modelFactory.obtenerProductosPublicados();
    }

    public boolean publicarProducto(ProductoDto productoDto) {
        return modelFactory.publicarProducto(productoDto);
    }
}
