package co.edu.uniquindio.finalprojectfx.finalprojectapp.utils;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.model.*;

import java.time.LocalDate;

public class DataUtil {

    public static MarketPlace inicializarDatos() {
        MarketPlace marketPlace = new MarketPlace();

        Vendedor vendedor1 = Vendedor.builder()
                .nombre("Esteban")
                .apellidos("Carmona")
                .cedula("1094878402")
                .direccion("MzB Cs2 Laureles")
                .usuario("ImEstebanCS")
                .contrasena("Juanito2004")
                .build();

        Vendedor vendedor2= Vendedor.builder()
                .nombre("Manuel")
                .apellidos("Rojas")
                .cedula("1000456562")
                .direccion("Laureles Armenia")
                .usuario("ImRojasAFK")
                .contrasena("123456789")
                .build();

        Producto producto1 = Producto.builder()
                .nombre("Saco Verde a Cuadros")
                .imagen("C:\\Users\\Asus\\OneDrive\\Imágenes\\pxfuel.JPG")
                .categoria("Ropa - Hombre")
                .precio(800)
                .estadoProducto("guardado")
                .fechaPublicacion(LocalDate.of(2023, 7, 5))
                .build();

        Producto producto2 = Producto.builder()
                .nombre("Camisa Hombre")
                .imagen("C:\\Users\\Asus\\OneDrive\\Imágenes\\pxfuel.JPG")
                .categoria("Ropa Hombre")
                .precio(2000)
                .estadoProducto("Publicado")
                .fechaPublicacion(LocalDate.of(2024,7,5))
                .build();

        marketPlace.getListaVendedores().add(vendedor1);
        vendedor1.getListaProductos().add(producto2);
        marketPlace.getListaVendedores().add(vendedor2);
        vendedor2.getListaProductos().add(producto1);

        marketPlace.getListaProductos().add(producto1);
        marketPlace.getListaProductos().add(producto2);
        return marketPlace;
    }
}
