package co.edu.uniquindio.finalprojectfx.finalprojectapp.viewcontroller;

import java.io.File;
import java.net.URL;
import java.net.http.WebSocket;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.controller.VendedorController;
import co.edu.uniquindio.finalprojectfx.finalprojectapp.mapping.dto.ProductoDto;
import co.edu.uniquindio.finalprojectfx.finalprojectapp.model.Vendedor;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import static co.edu.uniquindio.finalprojectfx.finalprojectapp.utils.MarketPlaceConstantes.*;

public class VendedorViewController {

    public String usuarioVendedor;
    VendedorController vendedorController;
    ObservableList<ProductoDto> listaProductos = FXCollections.observableArrayList();
    ProductoDto productoSeleccionado;;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btnActualizar;

    @FXML
    private Button btnAgregar;

    @FXML
    private Button btnAgregarImagen;

    @FXML
    private Button btnLimpiarCampos;

    @FXML
    private Button btnPublicarProducto;

    @FXML
    private Button btneEliminar;

    @FXML
    private ImageView imagenProducto;

    @FXML
    private DatePicker dpFechaPublicacion;

    @FXML
    private TableView<ProductoDto> tableProductos;

    @FXML
    private TableColumn<ProductoDto, String> tcCategoria;

    @FXML
    private TableColumn<ProductoDto, String> tcEstado;

    @FXML
    private TableColumn<ProductoDto, String> tcFecha;

    @FXML
    private TableColumn<ProductoDto, String> tcNombre;

    @FXML
    private TableColumn<ProductoDto, Double> tcPrecio;

    @FXML
    private TextField txtCategoria;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtPrecio;

    @FXML
    private TextField txtDescripcion;



    @FXML
    void initialize() {
        vendedorController = new VendedorController();
        initView();
        obtenerProductos();
    }

    private void initView() {
        initDataBinding();
        tableProductos.getItems().clear();
        tableProductos.setItems(listaProductos);
        listenerSelection();
    }

    private void obtenerProductos() {
        listaProductos.addAll(vendedorController.obtenerProductosVendedor(usuarioVendedor));
    }

    private void initDataBinding() {
        tcNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().nombre()));
        tcCategoria.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().categoria()));
        tcPrecio.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().precio()).asObject());
        tcEstado.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().estadoProducto().toString()));
        tcFecha.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().fechaPublicacion().toString()));
        /*tcFecha.setCellFactory(_ -> new TableCell<>() {
            @Override
            protected void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.toString());
                }
            }
        });*/
    }

    private void listenerSelection() {
        tableProductos.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            productoSeleccionado = newSelection;
            mostrarInformacionProducto(productoSeleccionado);
        });
    }

    @FXML
    void onAgregraProducto(ActionEvent event) {
        agregarProducto();
    }

    private void agregarProducto() {
        ProductoDto productoDto = crearProductoDto();
        if(datosValidos(productoDto)) {
            if(vendedorController.agregarProducto(productoDto)) {
                listaProductos.add(productoDto);
                limpiarCampos();
                mostrarMensaje(TITULO_PRODUCTO_AGREGADO, HEADER, BODY_PRODUCTO_AGREGADO, Alert.AlertType.INFORMATION);
                cargarProductosVendedor();
            } else {
                mostrarMensaje(TITULO_PRODUCTO_NO_AGREGADO, HEADER, BODY_PRODUCTO_NO_AGREGADO,Alert.AlertType.ERROR);
            }
        } else {
            mostrarMensaje(TITULO_INCOMPLETO, HEADER, BODY_INCOMPLETO, Alert.AlertType.WARNING);

        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtCategoria.setText("");
        txtDescripcion.setText("");
        dpFechaPublicacion.setValue(null);
        imagenProducto.setImage(null);
    }

    private boolean datosValidos(ProductoDto productoDto) {
        return productoDto != null && !productoDto.nombre().isBlank() ||
                !productoDto.categoria().isBlank() ||
                productoDto.precio() != null ||
                productoDto.fechaPublicacion() != null ||
                productoDto.descripcion().isBlank() ||
                !productoDto.imagen().isEmpty();
    }

    private void mostrarInformacionProducto(ProductoDto productoSeleccionado) {
        if(productoSeleccionado != null) {
            txtNombre.setText(productoSeleccionado.nombre());
            txtCategoria.setText(productoSeleccionado.categoria());
            txtPrecio.setText(String.valueOf(productoSeleccionado.precio()));
            dpFechaPublicacion.setValue(productoSeleccionado.fechaPublicacion());
            txtDescripcion.setText(productoSeleccionado.descripcion());
            cargarImagen();
        }
    }

    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert aler = new Alert(alertType);
        aler.setTitle(titulo);
        aler.setHeaderText(header);
        aler.setContentText(contenido);
        aler.showAndWait();
    }

    private boolean mostrarMensajeConfirmacion(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setTitle("Confirmación");
        alert.setContentText(mensaje);
        Optional<ButtonType> action = alert.showAndWait();
        if (action.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }

    private void cargarImagen() {
        try {
            imagenProducto.setVisible(true);
            imagenProducto.setImage(new Image("file:" + productoSeleccionado.imagen()));
            System.out.println(productoSeleccionado.imagen());
        } catch (Exception e) {
            imagenProducto.setImage(null);
            mostrarMensaje(TITULO_ERRROR_IMAGEN, BODY_ERRROR_IMAGEN+ e.getMessage(), HEADER, Alert.AlertType.ERROR);
        }
    }

    @FXML
    void onEliminarProducto(ActionEvent event) {
        eliminarProducto();
    }

    private void eliminarProducto() {
        boolean productoEliminado = false;
        if(productoSeleccionado != null) {
            if(mostrarMensajeConfirmacion("¿Estás seguro de eliminar este producto?")){
                productoEliminado = vendedorController.eliminarProducto(productoSeleccionado.nombre());
                if(productoEliminado == true){
                    listaProductos.remove(productoSeleccionado);
                    productoSeleccionado = null;
                    tableProductos.getSelectionModel().clearSelection();
                    limpiarCampos();
                    mostrarMensaje(TITTLE_SELLER_PRODUCTO, HEADER_SELLER_ELIMINATED_PRODUCTO, CONTENT_SELLER_DELECTED_PRODUCTO, Alert.AlertType.INFORMATION);
                    cargarProductosVendedor();
                }
            } else {
                mostrarMensaje(TITTLE_SELLER_PRODUCTO, HEADER_SELLER_NOT_DELECTED_PRODUCTO, CONTENT_SELLER_NOT_DELECTED_PRODUCTO, Alert.AlertType.WARNING);
            }
        }
    }

    @FXML
    void onActualizarProducto(ActionEvent event) {
        actualizarProducto();
    }

    private void actualizarProducto() {
        boolean productoActualizado = false;
        String nombreActual = productoSeleccionado.nombre();
        ProductoDto productoDto = crearProductoDto();
        if(productoSeleccionado != null) {
            if(datosValidos(productoDto)){
                productoActualizado = vendedorController.actualizarProducto(nombreActual, productoDto);
                if(productoActualizado){
                    cargarProductosVendedor();
                    for (ProductoDto producto : listaProductos) {
                        if (producto.nombre().equals(productoDto.nombre())) {
                            tableProductos.getSelectionModel().select(producto);
                            productoSeleccionado = producto;
                            mostrarInformacionProducto(producto);
                            break;
                        }
                    }
                    mostrarMensaje(TITTLE_SELLER_PRODUCTO, HEADER_UPDATED_SELLER_PRODUCTO,
                            CONTENT_UPDATED_SELLER_PRODUCTO, Alert.AlertType.INFORMATION);
                } else {
                    mostrarMensaje(TITTLE_SELLER_PRODUCTO, HEADER_SELLER_NOT_UPDATED_PRODUCTO,
                            CONTENT_SELLER_NOT_UPDATED_PRODUCTO, Alert.AlertType.WARNING);
                }
            } else {
                mostrarMensaje(TITTLE_SELLER_PRODUCTO, "Producto no creado",
                        "Los datos ingresados no son validos", Alert.AlertType.ERROR);
            }
        }
    }

    private ProductoDto crearProductoDto() {
        String nombre = txtNombre.getText();
        String categoria = txtCategoria.getText();
        String descripcion = txtDescripcion.getText();
        LocalDate fechaPublicacion = dpFechaPublicacion.getValue();
        String estadoProducto = "Guardado";

        String imagen = "";
        if (imagenProducto.getImage() != null) {
            imagen = imagenProducto.getImage().getUrl();
        }

        double precio;
        try {
            precio = Double.parseDouble(txtPrecio.getText());
        } catch (NumberFormatException e) {
            mostrarMensaje(TITULO_ERROR_EN_PRECIO, HEADER, BODY_NUMERO_INVALIDO, Alert.AlertType.ERROR);
            return null;
        }

        if(fechaPublicacion == null) {
            mostrarMensaje(TITULO_ERROR_FECHA, HEADER, BODY_FECHA_INVALIDA, Alert.AlertType.ERROR);
            return null;
        }

        return new ProductoDto(nombre, categoria, precio, fechaPublicacion, estadoProducto, imagen, descripcion);
    }


    @FXML
    void onPublicarProducto(ActionEvent event) {
        PublicarProducto();
    }

    private void PublicarProducto() {
        ProductoDto productoDto = crearProductoDto();
        if(productoDto != null && datosValidos(productoDto)) {
            ProductoDto productoPublicado = new ProductoDto(
                    productoDto.nombre(),
                    productoDto.categoria(),
                    productoDto.precio(),
                    productoDto.fechaPublicacion(),
                    "Publicado",
                    productoDto.imagen(),
                    productoDto.descripcion()
            );

            boolean publicado = vendedorController.publicarProducto(productoPublicado);
            if (publicado) {
                listaProductos.remove(productoSeleccionado);
                tableProductos.refresh();

                productoSeleccionado = null;
                limpiarCampos();

                cargarProductosVendedor();

                mostrarMensaje(TITULO_PRODUCTO_PUBLICADO, HEADER, BODY_PRODUCTO_PUBLICADO, Alert.AlertType.INFORMATION);
            } else {
                mostrarMensaje(TITULO_PRODUCTO_NO_PUBLICADO, HEADER, BODY_PRODUCTO_NO_PUBLICADO, Alert.AlertType.ERROR);
            }
        } else {
            mostrarMensaje(TITULO_INCOMPLETO, HEADER, BODY_INCOMPLETO, Alert.AlertType.WARNING);
        }
    }

    private void cargarProductosVendedor() {
        if (usuarioVendedor != null && !usuarioVendedor.isEmpty()) {
            listaProductos.clear();
            List<ProductoDto> productos = vendedorController.obtenerProductosVendedor(usuarioVendedor);
            if (productos != null && !productos.isEmpty()) {
                listaProductos.addAll(productos);
            }
            tableProductos.refresh();
        }
    }

    public void setUsuarioVendedor(String usuarioVendedor) {
        this.usuarioVendedor = usuarioVendedor;
    }

    @FXML
    void onLimpiarCampos(ActionEvent event) {
        limpiarCamposProducto();
    }

    private void limpiarCamposProducto() {
        txtNombre.setText("");
        txtCategoria.setText("");
        txtPrecio.setText("");
        txtDescripcion.setText("");
        imagenProducto.setVisible(false);
        tableProductos.getItems().clear();
        tableProductos.setItems(listaProductos);
        obtenerProductos();
    }

    @FXML
    void onAgregarImagen(ActionEvent event) {
        agregarImagen();
    }

    private void agregarImagen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        File archivoSeleccionado = fileChooser.showOpenDialog(new Stage());
        if(archivoSeleccionado != null) {
            String rutaImagen = archivoSeleccionado.getAbsolutePath();
            imagenProducto.setVisible(true);
            imagenProducto.setImage(new Image("file:" + rutaImagen));
        }
    }
}








