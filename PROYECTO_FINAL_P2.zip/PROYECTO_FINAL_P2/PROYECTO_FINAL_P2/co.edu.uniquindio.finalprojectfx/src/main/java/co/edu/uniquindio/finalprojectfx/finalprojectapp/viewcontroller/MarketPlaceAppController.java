package co.edu.uniquindio.finalprojectfx.finalprojectapp.viewcontroller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.model.MarketPlace;
import co.edu.uniquindio.finalprojectfx.finalprojectapp.model.Vendedor;
import co.edu.uniquindio.finalprojectfx.finalprojectapp.utils.DataUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;

public class MarketPlaceAppController {


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Tab AdministradorTab;

    @FXML
    private Tab VendedorTab;

    @FXML
    private TabPane mainTab;


    @FXML
    void initialize() {
        try {
            URL administradorViewUrl = getClass().getResource("/co/edu/uniquindio/finalprojectfx/finalprojectapp/Administrador.fxml");
            System.out.println("URl encontrada: " + administradorViewUrl);

            if (administradorViewUrl == null) {
                throw new IOException("No se puede encontrar Administrador.fxml en la ruta especificada.");
            }

            FXMLLoader loader = new FXMLLoader(administradorViewUrl);
            AnchorPane administradorContent = loader.load();
            AdministradorViewController administradorController = loader.getController();
            administradorController.setMarketPlaceAppController(this);
            AdministradorTab.setContent(administradorContent);

            MarketPlace marketPlace = DataUtil.inicializarDatos();

            for (Vendedor vendedor : marketPlace.getListaVendedores()) {
                agregarTabVendedor(vendedor.getUsuario());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void agregarTabVendedor(String usuario) {
        if (usuario == null || usuario.isEmpty()){
            System.out.println("Usuario no puede estar vacío.");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/finalprojectfx/finalprojectapp/Vendedor.fxml"));
            AnchorPane vendedorContent = loader.load();
            VendedorViewController vendedorController = loader.getController();
            Tab nuevoTab = new Tab();
            vendedorController.setUsuarioVendedor(usuario);
            nuevoTab.setText(usuario);
            nuevoTab.setContent(vendedorContent);
            mainTab.getTabs().add(nuevoTab);
            vendedorController.initialize();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error al cargar Vista de Vendedor.");
        }

    }

    public void eliminarTabVendedor (String cedula) {
        if (cedula == null || cedula.isEmpty()) {
            System.out.println("Usuario no puede estar vacío.");
            return;
        }
        Tab tabToRemove = null;
        for (Tab tab : mainTab.getTabs()) {
            if (cedula.equals(tab.getText())) {
                tabToRemove = tab;
                break;
            }
        }
        if (tabToRemove != null) {
            mainTab.getTabs().remove(tabToRemove);
            System.out.println(("Tab con Usuario " + cedula + " eliminado"));
        } else {
            System.out.println("No se Encontró un tab con el Usuario " + cedula);
        }
    }

}

