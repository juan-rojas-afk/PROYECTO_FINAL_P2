package co.edu.uniquindio.finalprojectfx.finalprojectapp.model;

public class ProductoException extends Exception {
    public ProductoException(String mensaje ) {
        super(mensaje);
    }
}
