package co.edu.uniquindio.finalprojectfx.finalprojectapp.model;

import co.edu.uniquindio.finalprojectfx.finalprojectapp.model.builder.ProductoBuilder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Producto {
    private String nombre;
    private String imagen;
    private String categoria;
    private double precio;
    private String estadoProducto;
    private LocalDate fechaPublicacion;
    private String descripcion;
    private int likes;
    private List<String> usuariosLike = new ArrayList<>();

    private List<Comentario> comentarios = new ArrayList<>();

    public Producto(String nombre,
                    String imagen,
                    String categoria,
                    double precio,
                    String estadoProducto,
                    LocalDate fechaPublicacion,
                    String descripcion) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.categoria = categoria;
        this.precio = precio;
        this.estadoProducto = estadoProducto;
        this.fechaPublicacion = fechaPublicacion;
        this.descripcion = descripcion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setEstadoProducto(String estadoProducto) {
        this.estadoProducto = estadoProducto;
    }

    public void setFechaPublicacion(LocalDate fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getImagen() {
        return imagen;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public String getEstadoProducto() {
        return estadoProducto;
    }

    public LocalDate getFechaPublicacion() {
        return fechaPublicacion;
    }

    public List<Comentario> getComentarios() {
        return comentarios;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getIkes() {
        return likes;
    }

    public static ProductoBuilder builder() {
        return new ProductoBuilder();
    }


    public boolean toggleLike(String usuario) {
        if (usuariosLike.contains(usuario)) {
            usuariosLike.remove(usuario);
            likes--;
            return false;
        } else {
            usuariosLike.add(usuario);
            likes++;
            return true;
        }
    }

    public boolean tieneUsuarioLike(String usuario) {
        return usuariosLike.contains(usuario);
    }

    public void agregarComentario(String usuario, String contenido) {
        comentarios.add(new Comentario(usuario, contenido));
    }

    public List<String> obtenerComentariosFormateados() {
        return comentarios.stream()
                .map(c -> c.getUsuario() + ": " + c.getContenido())
                .collect(Collectors.toList());
    }

}