package co.edu.uniquindio.finalprojectfx.finalprojectapp.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Publicacion {
    public String nombre;
    public String idProducto;
    public String descripcion;
    public LocalDate fecha;
    public List<Comentario> comentarios= new ArrayList<>();
    public List<String> likes = new ArrayList<>();

    public Publicacion(String nombre,String idProducto, String descripcion, List<String> likes, LocalDate fecha, List<Comentario> comentarios) {
        this.nombre = nombre;
        this.idProducto = idProducto;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.comentarios = comentarios;
    }

    public Publicacion() {}

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getLikes() {
        return likes.size();
    }

    public void setLikes(String nikeName) {
        likes.add(nikeName);
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public List<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(List<Comentario> comentarios) {
        this.comentarios = comentarios;
    }
}
